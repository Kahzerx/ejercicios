mod calculator;
mod process;
mod create_calc;

fn main() {
    calculator::run();
}
